interface userDetails {
    firstname: string;
    lastname: string;
    extra?: string;
}

export default userDetails;