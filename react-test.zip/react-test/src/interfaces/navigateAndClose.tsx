import { NavigateFunction } from "react-router-dom";

interface navigateAndClose {
    path: string;
    navigateFunction: NavigateFunction;
    closeDrawer: React.Dispatch<React.SetStateAction<boolean>>;
}

export default navigateAndClose;