//import ToggleTheme from "./ToggleTheme.tsx";
import SettingsEthernetIcon from '@mui/icons-material/SettingsEthernet';
import { AppBar, Box, Button, Drawer, IconButton, Stack, Toolbar, Typography } from '@mui/material';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import MenuIcon from '@mui/icons-material/Menu';
import CloseIcon from '@mui/icons-material/Close';
import HomeIcon from '@mui/icons-material/Home';

//interfaces
import navigateAndClose from '../interfaces/navigateAndClose';

//constants
const drawerButtonSize='48px';

function navigateAndClose(navigateAndClose: navigateAndClose): void {
    navigateAndClose.navigateFunction(navigateAndClose.path);
    navigateAndClose.closeDrawer(false);
}

function NavBar(): JSX.Element {
    const navigate = useNavigate();
    const [isDrawerOpen, setIsDrawerOpen] = useState(false);
    return (
        <>
            <Drawer anchor='left' open={isDrawerOpen} onClose={() => setIsDrawerOpen(false)}>
                <Box width='300px' height={'100%'} role='presentation' display={'flex'} flexDirection='column' bgcolor={'background.default'}>
                    <Box marginBottom={'6px'} p={1} width={'100%'} display={'inline-flex'} justifyContent={'space-between'} alignItems={'center'} height='64px' bgcolor='primary.dark' boxShadow={4}>
                        <Typography variant='h6' component='div'>
                            Admin Panel
                        </Typography>
                        <Box>
                            <IconButton size='large' onClick={() => {const navAndClose:navigateAndClose = {path: '/',navigateFunction: navigate, closeDrawer: setIsDrawerOpen}; navigateAndClose(navAndClose)}}>
                                <HomeIcon />
                            </IconButton>
                            <IconButton size='large' onClick={() => setIsDrawerOpen(false)}>
                                <CloseIcon />
                            </IconButton>
                        </Box>
                    </Box>
                    <Box marginBottom={'4px'} width={'100%'} height={drawerButtonSize} display={'flex'} flexDirection={'row'}>
                        <Button startIcon={<HomeIcon />} variant='contained' sx={{borderRadius: '0px', minHeight:drawerButtonSize, justifyContent: "flex-start"}} fullWidth onClick={() => {const navAndClose: navigateAndClose = {path: '/about', navigateFunction: navigate, closeDrawer: setIsDrawerOpen}; navigateAndClose(navAndClose) }}>About</Button>
                    </Box>
                    <Box marginBottom={'4px'} width={'100%'} display={'inline-flex'} alignItems={'center'} height={drawerButtonSize}>
                        <Button startIcon={<HomeIcon />} variant='contained' sx={{borderRadius: '0px', minHeight:drawerButtonSize, justifyContent: "flex-start"}} fullWidth onClick={() => {const navAndClose: navigateAndClose = {path: '/about', navigateFunction: navigate, closeDrawer: setIsDrawerOpen}; navigateAndClose(navAndClose) }}>About2</Button>
                    </Box>
                </Box>
            </Drawer>
            <AppBar position='static' sx={{ bgcolor: 'primary.dark', backgroundBlendMode: 'color' }}>
                <Toolbar>
                    <IconButton size='large' edge='start' onClick={() => setIsDrawerOpen(true)}>
                        <MenuIcon />
                    </IconButton>
                    <Box p={1} sx={{ flexGrow: 1, display: 'inline-flex', alignItems: 'center' }}>
                        <Typography variant='h6' component={'div'} sx={{ paddingRight:'18px'}}>
                            RCSA Admin Console
                        </Typography>
                        <IconButton size='large' edge='start'  onClick={() => {navigate('/')}}>
                            <SettingsEthernetIcon />
                        </IconButton>
                    </Box>
                    <Stack direction='row' spacing={1}>
                        <Button color='inherit' onClick={() => {navigate("/about")}}>About</Button>
                        <Button color='inherit'>Console</Button>
                        <Button color='inherit'>Admin</Button>
                        <Button color='inherit'>Happy Place</Button>
                        <Button color='inherit'>Login</Button>
                    </Stack>
                </Toolbar>
            </AppBar>
        </>
    );
}

export default NavBar;