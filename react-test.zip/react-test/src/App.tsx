// Libraries
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";

// MUI Themes
import { Theme, ThemeOptions, ThemeProvider, createTheme } from "@mui/material/styles";
import CssBaseline from "@mui/material/CssBaseline";

// Components
import Home from "./pages/Home";
import About from "./pages/About";
import NavBar from "./components/NavBar";
import useMediaQuery from "@mui/material/useMediaQuery";

// Utils
import defineTheme from "./utils/defineTheme";

let themeContext: ThemeOptions;
let theme: Theme;

function setTheme(): void{
  theme = createTheme({
    ...themeContext
  });
}

function App(): JSX.Element {
  
  const prefersDarkMode = useMediaQuery('(prefers-color-scheme: dark)');

  if (prefersDarkMode) {
    themeContext=defineTheme("dark");
    setTheme();
  } else {
    themeContext=defineTheme("light")
    setTheme();
  }

  console.log(themeContext)

  return (
    <>
      <ThemeProvider theme={theme}>
      <CssBaseline />
        <Router>
          <NavBar />
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/about/:id" element={<About />} />
          </Routes>
        </Router>
      </ThemeProvider>
    </>
  )
}

export default App
