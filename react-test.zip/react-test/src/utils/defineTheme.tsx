import { ThemeOptions } from "@mui/material"

export default function defineTheme(prefferedTheme: string): ThemeOptions {
    if (prefferedTheme === "dark"){
        return({
            palette: {
            mode: "dark",
            background: {
              default: '#1e2124'
            },
            primary: {
              light: '#424549',
              main: '#36393e',
              dark: '#282b30',
              contrastText: '#fff',
            },/*
            secondary: {
              light: '#ff7961',
              main: '#f44336',
              dark: '#ba000d',
              contrastText: '#000',
            },*/
          },
          shape: {
            borderRadius: 4
          },
          components: {
            MuiIconButton: {
                styleOverrides: {
                    root: {
                        borderRadius: '10px',
                    },
                },
            },
          }
        ,})
    } else {
        return({palette: {
            mode: "light",
            background: {
              default: '#FAF9F6'
            },/*
            primary: {
              light: '#757ce8',
              main: '#3f50b5',
              dark: '#002884',
              contrastText: '#fff',
            },
            secondary: {
              light: '#ff7961',
              main: '#f44336',
              dark: '#ba000d',
              contrastText: '#000',
            },*/
          },})
    }
}